import { Body, Controller, ForbiddenException, Post } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IsIn, IsOptional, IsString } from 'class-validator';
import { AuthService } from './auth.service';
import { PlatformRole } from '../common/types';

class DevTokenDto {
  @IsString() userId: string;
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsIn(['admin', 'staff', 'doctor', 'user']) platformRole?: PlatformRole;
}

@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly config: ConfigService,
  ) {}

  @Post('dev-token')
  async devToken(@Body() body: DevTokenDto) {
    if ((this.config.get<string>('NODE_ENV') ?? 'development') === 'production') {
      throw new ForbiddenException('Dev token endpoint is disabled in production');
    }
    return { accessToken: await this.auth.issueDevToken(body) };
  }
}
